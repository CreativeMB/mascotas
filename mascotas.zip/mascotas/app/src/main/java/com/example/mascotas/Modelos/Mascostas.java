package com.example.mascotas.Modelos;

public class Mascostas {
    private final String ID;
    private String raza;
    private String nombre;
    private int edad;

    public Mascostas(String ID,String raza, String nombre, int edad) {
        this.ID=ID;
        this.raza = raza;
        this.nombre = nombre;
        this.edad = edad;

    }

    public Mascostas(String ID) {
        this.ID=ID;
    }

    public String getID() {
        return ID;
    }

    public String getRaza() {
        return raza;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return
                " raza='" + raza + '\'' +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad ;


    }
}
